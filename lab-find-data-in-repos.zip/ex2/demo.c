int main() {
	printf("Yay!\n");
}
