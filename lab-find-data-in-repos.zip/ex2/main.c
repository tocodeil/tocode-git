#include <stdio.h>

int main() {
	printf("Yay I saved the world today\n");
	return 0;
}
