#include <stdio.h>

// a really important function
int main() {
	printf("Yay I saved the world today\n");
	return 0;
}
